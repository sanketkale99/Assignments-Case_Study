import java.util.Scanner;
public class StudentInfo {
	
	Scanner sc=new Scanner(System.in);
	public Student InsertData()
	{
		System.out.println( "Enter Student Id : ");
		int studId=sc.nextInt();
		System.out.println(" Enter Student Name : ");
		String sName=sc.next();
		Student sobj=new Student(studId,sName);
		return sobj;
		
	}
	public void displayData(Student student)
	{
		System.out.println(" Student Id : "+student.getStudId());
		System.out.println(" Student Name : "+student.getsName());
	}
	
	public Student[] Accept()
	{
		System.out.println(" Enter How Many Student Do You Want : ");
		int n=sc.nextInt();
		Student arr[]=new Student[n];
		for(int i=0;i<arr.length;i++)
		{
			System.out.println( "Enter Student Id : ");
			int studId=sc.nextInt();
			System.out.println(" Enter Student Name : ");
			String sName=sc.next();
			
			Student sobj=new Student(studId,sName);
			arr[i]=sobj;
		}
		return arr;
	}
	public void Display(Student sarr[])
	{
		for(int i=0;i<sarr.length;i++)
		{
			System.out.println(" Student Id : "+sarr[i].getStudId());
			System.out.println(" Student Name : "+sarr[i].getsName());
		}
	}
	
	
}
