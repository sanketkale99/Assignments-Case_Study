public class Student {

	private int studId;
	private String sName;
	public Student(int studId, String sName) {
		this.studId = studId;
		this.sName = sName;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	
	
	
	
}
