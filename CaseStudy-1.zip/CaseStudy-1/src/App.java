import java.util.Scanner;

public class App {
	StudentInfo sobj=new StudentInfo();
	void senario1()
	{
		Student student=sobj.InsertData();
		sobj.displayData(student);
	}
	void senario2()
	{
		Student sarr[]=sobj.Accept();
		sobj.Display(sarr);
	}
}
