import java.util.Scanner;
import java.util.Date;

public class StudentMain {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	App aobj=new App();
	do
	{
		System.out.println(" 1:Senario-1\n 2:Senario-2");
		System.out.println(" Enter Your Choice : ");
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				aobj.senario1();
				break;
			case 2:
				aobj.senario2();
				break;
		}
		System.out.println(" Press 1 to Continue : ");
	}while(sc.nextInt()==1);
		System.out.println("----------THANK YOU----------");

	}

}
