
public class USERTRAILMain {

//	public static void main(String[] args) {
//		
//		USERTRAIL u=new USERTRAIL(10, 0);
//		u.display();
//		System.out.println("---------------------------------------");
//		USERTRAIL u1=new USERTRAIL(-2,12);
//		u.display();
//		
//	}
}
