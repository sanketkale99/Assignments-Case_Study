import java.util.Scanner;

public class NumberMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Number n=new Number(0, 0);
		System.out.println(" Enter Any Two Numbers : ");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		int ch=0;
		do
		{
			
			System.out.println("1-Addition\n2-Substraction\n3-Multiplication\n4-Division");
			System.out.println(" Enter Your Choice : ");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				n.add(n1,n2);
				break;
			case 2:
				n.sub(n1,n2);
				break;
			case 3:
				n.mul(n1,n2);
				break;
			case 4:
				try 
				{
					n.div(n1,n2);
				} 
				catch(ArithmeticException e) 
				{
					System.out.println(" Exception Called.. "+e);
				}
				catch(Exception e)
				{
					System.out.println(" Another Exception.."+e);
				}
				break;
			}
			System.out.println(" Press 1 To Continue : ");
			ch=sc.nextInt();
		}while(ch==1);	
		System.out.println(" !!----------THANK YOU---------!!");
	}

}
