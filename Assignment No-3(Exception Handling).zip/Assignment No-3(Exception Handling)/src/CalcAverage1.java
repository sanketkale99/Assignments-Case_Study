
class Calcaverage1 extends Exception {
	
	public double avgFirstN(int n)throws IllegalArgumentException
	{
		double avg=0;
		double sum=0;
		
		try 
		{
			if(n<=0)
			{
				throw new IllegalArgumentException();
			}
			for(int i=1;i<=n;i++)
			{
				sum=sum+i;
			}
			avg=sum/n;
		} 
		catch(IllegalArgumentException e) 
		{
			System.out.println(" You Entered Negative Value...Please Retry... "+e);
			throw e;
		}
		catch(Exception e)
		{
			System.out.println(" Exception....");
		}
		
		return(avg);
	}
}
