import java.util.Scanner;

public class BankAccountMain {

public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println(" Enter Account Number,Customer Name ,Account Type ,Account Balance : ");
		BankAccount b=new BankAccount(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
		
			
			b.display();
			
			b.deposit(3000);
			b.display();
			
			b.withdraw(50000);
			b.display();
			
			b.withdraw(-1001);
			b.display();
	
		
	}

}
