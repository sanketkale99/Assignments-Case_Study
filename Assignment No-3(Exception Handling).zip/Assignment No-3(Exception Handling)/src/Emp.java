class Emp {

    private int empid;
    private String empName;
    private String designation;
    private double basic;
    private double hra;

    int getEmpid() {
        return empid;
    }
    void setEmpid(int empid) {
        this.empid = empid;
    }
    String getName() {
        return empName;
    }
    void setName(String name) {
        empName = name;
    }
    String getDesignation() {
        return designation;
    }
    void setDesignation(String designation) {
        this.designation = designation;
    }
    double getBasic() {
        if(basic<500)
        {
            try 
            {
                throw new LowSalException();

            } 
            catch (LowSalException e) 
            {
                System.out.println(" Exception Calling : "+e);
            }
        }
        return basic;
    }
    void setBasic(double basic) {
        this.basic = basic;
    }
    //constructor
    public Emp() {
        this.empid=101;
        this.empName="Aniket";
        this.designation="Other";
        this.basic=400;
    }
    //parametric constructor
    public Emp(int empid, String empName, String designation, double basic) {

        this.empid=empid;
        this.empName=empName;
        this.designation=designation;
        this.basic=basic;
    }

    //method
    public void printDET() {
    	System.out.println(" Employee Id : "+empid);
    	System.out.println(" Emplonee Name : "+empName);
    	System.out.println(" Employee Designation : "+designation);
    	System.out.println(" Employee Salary : "+basic);
    	
    }
    //method
    public void calculateHRA() {
        if(designation=="Manager") {

            hra=basic*0.1;
            System.out.println(" Manager HRA is : "+hra);
        }

        else if(designation=="Officer") {

            hra=basic*0.12;
            System.out.println(" Officer HRA is : "+hra);
        }

        else if(designation=="Clerk"){

            hra=basic*0.05;
            System.out.println(" Clerk HRA is : "+hra);
        }
    }
}

