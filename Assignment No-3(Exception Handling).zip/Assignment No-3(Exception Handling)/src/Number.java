class Number extends Exception {
	int a;
	int b;
	double result;
	
	Number(int x, int y)
	{
		a=x;
		b=y;
	}
	
	void add(int a,int b)
	{
		result=a+b;
		System.out.println(" Addition Is : "+result);
	}
	void sub(int a,int b)
	{
		result=a-b;
		System.out.println(" Substraction Is : "+result);
	}
	void mul(int a,int b)
	{
		result=a*b;
		System.out.println(" Multiplication Is : "+result);
	}
	void div(int a,int b)throws ArithmeticException 
	{
		try 
		{
			if(b<=0)
			{
				throw new ArithmeticException();
			}
			result=a/b;
			System.out.println(" Division Is : "+result);
		} 
		catch (ArithmeticException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("Number Is Less Than 0... "+e);
			throw e;
		}
	}
}


//import java.util.Scanner;
//
//public class Number {
//
//	private int first_number;
//	private int second_number;
//	private double result;
//	
//	
//	public Number(int first_number, int second_number) 
//	{
//		this.first_number = first_number;
//		this.second_number = second_number;
//	}
//	
//	public static void add()
//	{
//		
//	}
//	
//	public static void sub()
//	{
//		
//	}
//	
//	public static void mul()
//	{
//		
//	}
//	
//	public static void div()
//	{
//		
//	}
//	
//	public static void main (String[]Args)
//	{
//		Scanner sc=new Scanner(System.in);
//		
//	}
//	
//}
