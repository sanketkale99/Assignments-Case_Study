
public class USERTRAIL {

	private int val1;
	private int val2;
	
	//getters/setters
	public int getVal1() {
		return val1;
	}
	public void setVal1(int val1) {
		this.val1 = val1;
	}
	public int getVal2() {
		return val2;
	}
	public void setVal2(int val2) {
		this.val2 = val2;
	}
	
	//method
	public void booleanshow()
	{
		
	}
	//constructor and exception 
	public USERTRAIL(int val1, int val2) 
	{
		if(val1<0||val2<0)
		{
			try 
			{
				throw new IllegalValueException();
				
			} 
			catch (IllegalValueException e) 
			{
				// TODO Auto-generated catch block
				System.out.println("Exception Calling : " +e);
			}
			this.val1 = val1;
			this.val2 = val2;
		}	
	}
	//method to display values 
	public void display()
	{
		System.out.println(" Value If First Number IS : "+val1);
		System.out.println(" Value If Second Number IS : "+val2);
	}	
	
	//main method
	public static void main(String[] args) {
		
		USERTRAIL u=new USERTRAIL(-10,5);
		u.display();
		System.out.println("---------------------------------------");
		USERTRAIL u1=new USERTRAIL(-20,10);
		u1.display();
	}

}
