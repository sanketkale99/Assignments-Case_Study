
public class BankAccount {

	private int accNo;
	private String custName;
	private String accType;
	private double balance;
	
	//getter/setter
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getBalance() {
		if(balance<1000)
		{
			try 
			{
				throw new NumberFormatException();
			}
			catch(NumberFormatException e)
			{
				System.out.println(" Low Account Balance Exception...Your Account Balance Is  : "+balance);
			}
		}
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	//non-parametric constructor
//	public BankAccount() {
//		this.accNo = 101112;
//		this.custName = "Sanket";
//		this.accType = "Saving";
//		this.balance = 2500;
//	}
	//parametric constructor
		public BankAccount(int accNo, String custName, String accType, double balance) {
			this.accNo = accNo;
			this.custName = custName;
			this.accType = accType;
			this.balance = balance;
		}
	
	//methods
	public void deposit(double amt)
	{
		if(amt<0)
		{
			try 
			{
				throw new NumberFormatException();
			}
			catch(NumberFormatException n)
			{
				System.out.println(" You Entered Negative Amount..Please Enter Amount Greater Than 1....");
			}
		}
		else
		{
			balance=getBalance()+amt;
			System.out.println(" Depositted Amount Is : "+amt);
		}
	}
	public void withdraw(int amt)
	{
		if(amt>balance-1000)
		{
			try
			{
				throw new NumberFormatException();
			}
			catch(NumberFormatException n)
			{
				System.out.println(" Please Enter Valid Amount To Withdraw...Invalid Account Balance...");
			}
		}
		else
		{
			if(amt>0)
			{
				balance=getBalance()-amt;
				System.out.println(" Withdrawal Amount Is :"+amt);
			}
			else
			{
				System.out.println(" You Entered InValid Amount To Withdraw....");
			}
			
		}
	}
	
	void display()
	{
		if(balance>0)
		{
			System.out.println(" Total Account Balance IS : "+getBalance());
		}
		else
		{
			System.out.println(" Negative Account Balance...........");
		}
	}
	

}