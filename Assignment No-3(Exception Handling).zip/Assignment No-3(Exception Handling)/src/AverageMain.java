import java.util.Scanner;

class AverageMain {
	public static void main(String args[])
	{
		Calcaverage1 c=new Calcaverage1();
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Any Natural Number :");
		int num=sc.nextInt();
		
		double res;
		try 
		{
			res=c.avgFirstN(num);
			System.out.println("Average Of Given Number Is :"+res);
		} 
		catch (IllegalArgumentException e) 
		{
			System.out.println();
		}
		
	}
}