
public class IllegalValueException extends Exception{

	
	public String toString()
	{
		return"Illegal Value Exception Called...";
	}
}
