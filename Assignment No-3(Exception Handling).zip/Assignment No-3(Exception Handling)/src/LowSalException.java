
public class LowSalException extends Exception{
	
	public String toString()
	{
		return "Basic Salary Is Less Than 500 Rupees";
	}
}
