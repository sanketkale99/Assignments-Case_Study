
public class EmployeeMain {

	public static void main(String[] args) {
		
		Emp e = new Emp();
        e.getBasic();
        e.printDET();
        System.out.println("------------------------------------");
        
        Emp e1=new Emp(102,"Sanket","Manager",50000);
        e1.printDET();
        e1.calculateHRA();
        System.out.println("------------------------------------");
        
        Emp e2=new Emp(103,"Ani","Officer",10000);
        e2.printDET();
        e2.calculateHRA();
        System.out.println("------------------------------------");
        
        Emp e3=new Emp(104,"Adi","Clerk",4000);
        e3.printDET();
        e3.calculateHRA();
	}

}
