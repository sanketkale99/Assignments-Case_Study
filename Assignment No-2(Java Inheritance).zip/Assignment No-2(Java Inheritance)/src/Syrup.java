
public class Syrup extends Medicine{
	
	public void displayLabel()
	{
		System.out.println("------------Syrups----------");
		super.displayLabel();
		System.out.println("Place In Story And Dry Place..\nCheck Cap Is Seal Or Not Before purchase..");
	}
}
