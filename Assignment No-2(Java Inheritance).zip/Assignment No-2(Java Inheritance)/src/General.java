
public class General extends Compartment{ 
	 
	public void notice()
	{
		System.out.println(" --------General Compartment---------");
		System.out.println("1-Be Careful...");
		System.out.println("2-Keep Safe Distance...");
		System.out.println("3-Wear A Mask...");
	}

}
