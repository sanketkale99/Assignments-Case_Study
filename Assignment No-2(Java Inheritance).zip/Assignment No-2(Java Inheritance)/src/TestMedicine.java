
public class TestMedicine {

	public static void main(String[] args) {
		Medicine m[]=new Medicine[10];
		for(int i=0;i<9;i++)
		{
			int min=1;  
			int max=3;   
			System.out.println("Random value of type int between "+min+" to "+max+ ":");  
			int b=(int)(Math.random()*(max-min+1)+min);  
			System.out.println(b);
			if(b==1)
			{
				m[b]=new Tablet();
			}
			else if(b==2)
			{
				m[b]=new Syrup();
			}
			else if(b==3)
			{
				m[b]=new Ointment();
			}
			display(m);
		}
		/*int min=1;  
		int max=3;   
		System.out.println("Random value of type int between "+min+" to "+max+ ":");  
		int b=(int)(Math.random()*(max-min+1)+min);  
		System.out.println(b);
		if(b==1)
		{
			m[b]=new Tablet();
		}
		else if(b==2)
		{
			m[b]=new Syrup();
		}
		else if(b==3)
		{
			m[b]=new Ointment();
		}*/
//		m[0]=new Syrup();
//		m[1]=new Tablet();
//		m[2]=new Ointment();
//		m[3]=new Tablet();
		
		//display(m);
	}
	public static void display(Medicine marr[])
	{
		for(Medicine m:marr)
		{
			if(m instanceof Tablet)
			{
				m.displayLabel();
			}
			if(m instanceof Syrup)
			{
				m.displayLabel();
			}
			else if(m instanceof Ointment)
			{
				m.displayLabel();
			}
		}
	}
}
