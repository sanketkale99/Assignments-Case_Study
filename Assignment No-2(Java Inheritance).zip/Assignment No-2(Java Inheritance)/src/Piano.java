
public class Piano extends Instrument{
	
	public void play()
	{
		System.out.println(" Piano Is Playing tan tan tan tan.......");
	}
}
