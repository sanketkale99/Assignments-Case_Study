
public class Tablet extends Medicine{
	
	public void displayLabel()
	{
		System.out.println("------------Tablets----------");
		super.displayLabel();
		System.out.println("Stored In Cool And Dry Place....");
	}
}
