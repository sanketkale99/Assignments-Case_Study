
public class SportCar extends Car{
	private String AirBallonType;

	public SportCar(int speed, int noofGear, String airBallonType) {
		super(speed, noofGear);
		AirBallonType = airBallonType;
	}
	public void display()
	{
		super.display();
		System.out.println(" Air Balloon Type : "+AirBallonType);
	}

}
