import java.util.Scanner;
public class FoodMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int ch=0;		
		Food farr[]=new Food[4];
	
		do
		{
			System.out.println(" -------------------------------------------");
			System.out.println("1-PavBhaji\n2-Burger\n3-Vadpav");
			System.out.println(" Enter Your Choice : ");
			ch=sc.nextInt();
			for(Food f:farr)
			{
				if(ch==1)
				{
					farr[ch]=new PavBhaji();
					if(f instanceof PavBhaji)
					{
						System.out.println("----------Receipe Of PavBhaji----------");
						f.receipe();
					}
				}
				else if(ch==2)
				{
					farr[ch]=new Burger();
					if(f instanceof Burger)
					{
						System.out.println("----------Receipe Of Burger----------");
						f.receipe();
					}
				}
				else if(ch==3)
				{
					farr[ch]=new Vadapav();	
					if(f instanceof Vadapav)
					{
						System.out.println("----------Receipe Of Vadapav----------");
						f.receipe();
					}
				}			
			}
			
			System.out.println(" Press 1 to Continue : ");
			ch=sc.nextInt();
		}while(ch==1);
		System.out.println(" ------------THANK YOU------------");
		
		/*int min=1;  
		int max=3;   
		System.out.println("Random value of type int between "+min+" to "+max+ ":");  
		int b=(int)(Math.random()*(max-min+1)+min);  
		System.out.println(b);
		if(b==1)
		{
			f[b]=new PavBhaji();
		}
		else if(b==2)
		{
			f[b]=new Burger();
		}
		else if(b==3)
		{
			f[b]=new Vadapav();
		}*/
		//display(f);
		
	}
	/*public static void display(Food farr[])
	{
		for(Food f:farr)
		{
			if(f instanceof PavBhaji)
			{
				System.out.println("----------Receipe Of PavBhaji----------");
				f.receipe();
			}
			else if(f instanceof Burger)
			{
				System.out.println("----------Receipe Of Burger----------");
				f.receipe();
			}
			else if(f instanceof Vadapav)
			{
				System.out.println("----------Receipe Of Vadapav----------");
				f.receipe();
			}
		}
	}*/
}
