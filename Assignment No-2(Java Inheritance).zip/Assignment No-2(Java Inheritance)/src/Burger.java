
public class Burger implements Food{
	
	public void receipe()
	{
		System.out.println("1-Buying the right meat.\n2-Don�t overwork the meat while forming the perfect patties."
				+ "\n3-Keep �Em Cold!4-A Clean Grate."
				+ "\n5-You need a hot grill.-Handling your meat properly."
				+ "\n7-Cheese them babies and toast those buns.8-A rested burger is a juicy burger."
				+ "\n9-Crown your burgers with bacon.10-Burger Ready To Eat..!!!");
	}

}
