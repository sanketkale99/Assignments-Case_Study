
public class FirstClass extends Compartment{
	public void notice()
	{
		System.out.println(" --------FirstClass Compartment---------");
		System.out.println("1-You cannot travel in first-class accommodation with a standard class ticket.");
		System.out.println("2-Extra Leg And Elbow Room..");
		System.out.println("3-All passengers travelling in First Class will receive complimentary food and drink.");
	}
}
