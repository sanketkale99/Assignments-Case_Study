import java.util.Scanner;

public class InstrumentsMain {

	public static void main(String[] args) {

			Scanner sc=new Scanner(System.in);
			Instrument s[]=new Instrument[10];
			
			s[0]=new Flute();
			s[1]=new Guitar();
			s[2]=new Piano();
			s[3]=new Flute();
			s[4]=new Guitar();
			s[5]=new Flute();
			s[6]=new Piano();
			s[7]=new Guitar();
			s[8]=new Piano();
			s[9]=new Flute();
			
			display(s);
			
	}
	public static void display(Instrument iarr[])
	{
		for(Instrument i:iarr)
		{
			if(i instanceof Flute)
			{
				i.play();
			}
			else if(i instanceof Guitar)
			{
				i.play();
			}
			else if(i instanceof Piano)
			{
				i.play();
			}
		}
	}
}
