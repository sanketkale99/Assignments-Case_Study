
public class Luggage extends Compartment{
		
	public void notice()
	{
		System.out.println(" --------Luggage Compartment---------");
		System.out.println("1-Lock Your Luggage While Travelling..");
		System.out.println("2-Dont Put valuable Thing In Your Bag..");
		System.out.println("3-Be Aware From Fraud Persons..");
	}

}
