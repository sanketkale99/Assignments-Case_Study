
public class PavBhaji implements Food{
	
	public void receipe()
	{
		System.out.println("1-Put into a pot the potatoes, cauliflower, aubergine and mixed vegetables."
				+ "\n2-Cover with water until just above the vegetables, then bring to a boil."
				+ "\n3- Boil for approx. 25 minutes or until cooked.\n"
				+ "\n 4-When the vegetables are cooked to slightly softer than al dente, check the water level. "
				+ "\n5-If there is a lot of water, remove it and set it aside. You may need this water to thin out the pav bhaji later, without losing flavour.+"
				+ "\n6-Mash the vegetable mixture with a potato masher until it has the consistency of thick rice congee.\n"
				+ "\n7-Finnally We Made A Pav Bhaji......!!!!!!! ");
	}
}
