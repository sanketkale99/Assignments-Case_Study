
public interface Food {
	
	abstract void receipe();
}
