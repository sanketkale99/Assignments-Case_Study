
public class CarMain {

	public static void main(String[] args) {

		SportCar s=new SportCar(200,5, "Yes");
		s.display();
	}
}
