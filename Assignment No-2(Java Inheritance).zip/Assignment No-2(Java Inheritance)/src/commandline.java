public class commandline {
	public static void main(String [] args) {
		int a=Integer.parseInt(args[0]);//type string to casting
		int b=Integer.parseInt(args[1]);//type casting
		
		String operator=args[2];//args[2] for operator of input
		
		System.out.println("\n\t\t------------------------------------------------------");
		System.out.println("\t\tNumber 1 :- "+a);
		System.out.println("\t\tNumber 2 :- "+b);
		System.out.println("\t\tOperator :- "+operator);
		System.out.println("\n\t\t------------------------------------------------------");
		if(operator.equals("+"))
		{
			System.out.println("\t\t\tThe Addition Is "+(a+b));
		}
		else if(operator.equals("-"))
		{
			System.out.println("\t\t\tThe Substraction Is "+(a+b));
		}
		else if(operator.equals("'*'"))
		{
			System.out.println("\t\t\tThe Multiplication Is "+(a*b));
		}
		else if(operator.equals("/"))
		{
			System.out.println("\t\t\tThe Division Is "+(a/b));
		}
		else
		{
			System.out.println("\t\tYou Have Entered Invalid Operator!!!");
		}
	}
}
