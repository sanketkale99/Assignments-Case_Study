
public class TestCompartment {
	public static void main(String[] args) {
		Compartment c[]=new Compartment[10];
		for(int i=0;i<10;i++)
		{
			int min=1;  
			int max=4;   
			System.out.println("Random value of type int between "+min+" to "+max+ ":");  
			int b = (int)(Math.random()*(max-min+1)+min);  
			System.out.println(b);
			if(b==1)
			{
				c[b]=new FirstClass();
			}
			else if(b==2)
			{
				c[b]=new Ladies();
			}
			else if(b==3)
			{
				c[b]=new General();
			}
			else if(b==4)
			{
				c[b]=new Luggage();
			}
			display(c);
		}
		/*
		int min=1;  
		int max=3;   
		System.out.println("Random value of type int between "+min+" to "+max+ ":");  
		int b = (int)(Math.random()*(max-min+1)+min);  
		System.out.println(b);
		if(b==1)
		{
			c[b]=new FirstClass();
		}
		else if(b==2)
		{
			c[b]=new Ladies();
		}
		else if(b==3)
		{
			c[b]=new General();
		}
		else if(b==4)
		{
			c[b]=new Luggage();
		}
		display(c);
		*/
//		c[b]=new Ladies();
//		c[1]=new Ladies();
//		c[2]=new Ladies();
//		c[3]=new Ladies();
//		c[4]=new Ladies();
//		c[5]=new Ladies();
//		c[6]=new Ladies();
//		c[7]=new Ladies();
//		c[8]=new Ladies();
//		c[9]=new Ladies();
		
		//display(c);	
	}
	public static void display(Compartment arr[])
	{
		for(Compartment c:arr)
		{
			if(c instanceof FirstClass)
			{
				c.notice();
			}
			else if(c instanceof Ladies)
			{
				c.notice();
			}
			else if(c instanceof General)
			{
				c.notice();
			}
			else if(c instanceof Luggage)
			{
				c.notice();
			}
		}
	}
}
