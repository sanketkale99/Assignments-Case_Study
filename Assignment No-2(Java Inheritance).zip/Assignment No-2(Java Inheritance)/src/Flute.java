
public class Flute extends Instrument{
	
	public void play()
	{
		System.out.println(" Flute IS Playing toot toot toot toot...........");
	}
}
