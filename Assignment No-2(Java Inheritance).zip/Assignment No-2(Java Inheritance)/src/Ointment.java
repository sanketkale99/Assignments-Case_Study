
public class Ointment extends Medicine{

	public void displayLabel()
	{
		System.out.println("------------Ointments----------");
		super.displayLabel();
		System.out.println("For External Use Only..");
	}
}
