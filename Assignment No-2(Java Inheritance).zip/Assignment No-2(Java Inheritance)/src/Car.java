import java.util.Scanner;

public class Car {
	Scanner sc=new Scanner(System.in);
	private int Speed;
	private int noofGear;
	
	public Car(int speed, int noofGear) {
		super();
		this.Speed = speed;
		this.noofGear = noofGear;
	}

	public void drive()
	{
		//System.out.println("Enter Starting Speed Of Car : ");
		//int speed=sc.nextInt();
		//System.out.println("Enter No Of Gears of Car : ");
		//int nofgear=sc.nextInt();
	}
	public void display()
	{
		System.out.println(" Starting Speed OF Car : "+Speed);
		System.out.println(" No Of Gears : "+noofGear);
	}
	
}
