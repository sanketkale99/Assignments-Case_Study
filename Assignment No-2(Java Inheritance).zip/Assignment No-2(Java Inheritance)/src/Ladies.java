
public class Ladies extends Compartment{
	
	public void notice()
	{
		System.out.println(" --------Ladies Compartment---------");
		System.out.println("1-Only Ladies Can Sit In Ladies Compartment");
		System.out.println("2-Gents not Allows in ladies Compartment..");
		System.out.println();
	}
}
