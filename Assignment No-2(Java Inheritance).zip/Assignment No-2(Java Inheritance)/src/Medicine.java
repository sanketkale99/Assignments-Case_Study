
public abstract class Medicine {

	public void displayLabel()
	{
		System.out.println("Company : Cipla");
		System.out.println("City : Pune\n State :"
				+ "Maharashtra\nPincode : 410005");
	}
}
