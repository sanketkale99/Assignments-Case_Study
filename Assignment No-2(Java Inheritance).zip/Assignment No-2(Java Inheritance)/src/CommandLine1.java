
public class CommandLine1 {

	public static void main(String[] args) {
		
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		
		String op=args[2];
		
		System.out.println("\t\tValue Of a Is : "+a);
		System.out.println("\t\tValue Of b is : "+b);
		System.out.println("\t\tOperator Is : "+op);
		
		if(op.equals("+"))
		{
			System.out.println("\n\t\tAddition IS : "+(a+b));
		}
		else if(op.equals("-"))
		{
			System.out.println("\n\t\tSubstraction Is : "+(a-b));
		}
		else if(op.equals("'*'"))
		{
			System.out.println("\n\t\tMultiplication Is : "+(a*b));
		}
		else if(op.equals("/"))
		{
			System.out.println("\n\t\tDivision Is : "+(a/b));
		}
	}

}
