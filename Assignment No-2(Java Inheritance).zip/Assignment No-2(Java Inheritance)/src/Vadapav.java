
public class Vadapav implements Food{
	
	public void receipe()
	{
		System.out.println("\n1-the vada pav recipe is extremely simple to prepare,"
				+ "\n2- yet i would like to add few tips and recommendations while preparing. "
				+ "\n3-firstly, ensure the boiled and mashed potatoes are moisture free and removed immediately from pressure cooker after it is cooked. "
				+ "\n4-if you feel you mashed potatoes contain moisture, fry them in a pan for 2-3 minutes to remove it."
				+ "\n5- secondly, i have added baking soda to the besan batter to make vadas crisper. "
				+ "\n6-also, add 1 tbsp of rice flour/cornflour to make it even crisper. "
				+ "\n7-lastly, these vada pav should be served immediately after deep frying and assembling. "
				+ "\n8-alternatively, you can place the deep fried vadas in a preheated oven or even deep fry again for 1 minute if serving later.");
	}

}
