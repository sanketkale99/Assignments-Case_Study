
public class Matrix10 {

	public static void main(String[] args) {
		
		int mat[][]=new int [10][10];
		
		
		
		
	}

}
