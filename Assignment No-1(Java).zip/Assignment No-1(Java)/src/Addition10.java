
public class Addition10 {

	private int rows;
	private int columns;
	
	public Addition10()
	{
		
	}
	
	public Addition10(int n1,int n2)
	{
			
	}
}
