
public class StringArgument6 {

	public static void main(String[] args) {
		
		String s=args[0];
		System.out.println("String Is : "+args[0]);
		System.out.println(" Length Of String Is : "+args[0].length());
		System.out.println(" UpperCase String Is : "+args[0].toUpperCase());
		
		String rev="";
		int l=args[0].length();
		 
	      for(int i=l-1;i>=0;i--)
	      {
	    	  rev=rev+args[0].charAt(i);
	      }
	      
	      if(args[0]==(rev))
	      {
	    	  System.out.println(args[0]+" is a palindrome");
	      }  
	      else
	      {
	    	  System.out.println(args[0]+" is not a palindrome");
	      }	
	
	}
}
