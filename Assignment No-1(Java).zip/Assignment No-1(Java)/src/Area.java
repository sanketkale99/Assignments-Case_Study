
public class Area {
	private float length=1;
	private float width=1;
	public Area(float length, float width) {
		super();
		this.length = length;
		this.width = width;
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public float getwidth() {
		return width;
	}
	public void setwidth(float width) {
		this.width = width;
	}
	
	
	public void calculatePermeter(float l,float w)
	{
		float ans=0;
		ans=2*(l+w);
		System.out.println("Perimeter Of Rectangle Is : "+ans);
	}
	
	public void calculateArea(float l,float w)
	{
		float a=0;
		a=l*w;
		System.out.println("Area Of Rectangle Is : "+a);
	}
	
}
