
public class CommandEx7 {

	public static void main(String[] args) {
		
		System.out.println(" Numbers Are : ");
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}
		int ans=0;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				ans=n1+n2;
				System.out.println(ans);
				n1=n2;
				n2=ans;
			}
		}
		
	}
//int arr[]=new int[args.length];
	
}
