public class AreaMain4Q {

	public static void main(String[] args) {
		
		Area a=new Area(0, 0);
		
		a.calculatePermeter(2.4f,3.5f);
		
		a.calculateArea(2.5f,7.8f);
		
	}
}
