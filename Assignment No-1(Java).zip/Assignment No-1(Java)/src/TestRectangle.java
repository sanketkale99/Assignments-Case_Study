public class TestRectangle {
	public static void main(String[] args) {
		
		Rectangle r1=new Rectangle(0,0);
		r1.area(1.2,3.);
		Rectangle r2=new Rectangle(0,0);
		r2.area(2.2,3.4);
		Rectangle r3=new Rectangle(0,0);
		r3.area(2.2,2.1);
		Rectangle r4=new Rectangle(0,0);
		r4.area(1.1,3.2);
		Rectangle r5=new Rectangle(0,0);	
		r5.area(4.4,5);
	}
}
