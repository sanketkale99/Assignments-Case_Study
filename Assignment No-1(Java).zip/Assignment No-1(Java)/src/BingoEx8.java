public class BingoEx8 {
	public static void main(String[] args) {
		
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		
		System.out.println(" First Number Is : "+args[0]);
		System.out.println(" Second Number Is : "+args[1]);
		
		int arr[]= {11,23,19,6,25};
		int flag=0,cnt=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==a)
			{
				flag=1;
			}
			if(arr[i]==b)
			{
				cnt=1;
			}
		}
		if(flag==1&&cnt==1)
		{
			System.out.println("Its BINGO!");
		}
		else if(flag==0&&cnt==0)
		{
			System.out.println("Not Found!");
		}
	}

}
