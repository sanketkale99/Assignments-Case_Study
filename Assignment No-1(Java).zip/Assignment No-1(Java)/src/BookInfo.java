import java.awt.print.Book;
import java.util.Scanner;
public class BookInfo {
	public void createBooks()
	{
		Scanner sc=new Scanner(System.in);
		int n=2;
		Book b[]=new Book[n];
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter book title:");
			String Book_tital=sc.next();
			System.out.println("Enter Book Price : ");
			int Book_price=sc.nextInt();
		}
	}
	
	public void showBooks()
	{
		System.out.println("Book Title\t\tPrice");
		System.out.println("Java Programming\tRs.350.50");
		System.out.println("Let Us C\t\tRs.200.00");
	}
}
