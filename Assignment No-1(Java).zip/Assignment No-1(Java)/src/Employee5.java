import java.util.Scanner;
public class Employee5 {
	public static void main(String[] args) {
		Date5 d=new Date5(0, 0, 0);

		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			System.out.println(" Enter Employee No : ");
			int empno=sc.nextInt();
			System.out.println(" Enter Employee Name : ");
			String ename=sc.next();
			System.out.println(" Enter Joining Date : ");
			int day=sc.nextInt();
			int mon=sc.nextInt();
			int year=sc.nextInt();
			
			System.out.println("-----------Emplpoyee "+(i+1)+" Details--------------");
			System.out.println("\tEmployee Number\t\t "+empno);
			System.out.println("\tEmployee Name\t\t "+ename);
			System.out.println("\tJoining Date\t\t "+day+"-"+mon+"-"+year+"\n");
		}
	}
}
