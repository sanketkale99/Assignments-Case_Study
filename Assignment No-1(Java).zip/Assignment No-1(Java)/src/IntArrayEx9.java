public class IntArrayEx9 {
	public static void main(String[] args) {
		int A[]={3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int sum=0,avg=0;
		for(int i=0;i<A.length-4;i++)
		{
			sum=sum+A[i];
		}
		A[15]=sum;
		System.out.println(" Sum Is : "+sum);
		avg=sum/14;
		System.out.println(" Avg Is : "+avg);
		A[16]=avg;
		int min=A[0];
		for(int i=0;i<A.length-4;i++)
		{
			if(min>A[i])
			{
				min=A[i];
			}
		}
		System.out.println("Min No Is : "+min);
		A[17]=min;
		
		System.out.println("Array Is : ");
		for(int i=0;i<A.length;i++)
		{
			System.out.print(A[i]+"\t");
		}
	}

}
