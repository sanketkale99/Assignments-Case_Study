public class Date5 {
	private int day;
	private int date;
	private int year;
	public Date5(int day, int date, int year) {
		super();
		this.day = day;
		this.date = date;
		this.year = year;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
}
